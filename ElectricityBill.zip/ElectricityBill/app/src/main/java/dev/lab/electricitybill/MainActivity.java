package dev.lab.electricitybill;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button buttonCalculate, buttonClear;
    EditText editTextKwH, editTextRebate;
    TextView resultView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonClear = findViewById(R.id.buttonClear);
        buttonCalculate = findViewById(R.id.buttonCalculate);
        editTextKwH = findViewById(R.id.editTextKwH);
        editTextRebate = findViewById(R.id.editTextRebate);
        resultView = findViewById(R.id.resultView);

        buttonCalculate.setOnClickListener(this);
        buttonClear.setOnClickListener(this);

        Toolbar myToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.about) {
            Intent intent = new Intent(this, About.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.energy_cost) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v == buttonCalculate) {
            String number2 = editTextRebate.getText().toString();
            String number1 = editTextKwH.getText().toString();

            if (number1.isEmpty() || number2.isEmpty()) {
                Toast.makeText(this, "Please enter numbers in the input fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double consumption = Double.parseDouble(number1);
                double rebatePercentage = Double.parseDouble(number2);
                double totalCharges;

                if (consumption <= 200) {
                    totalCharges = consumption * 0.218;
                } else if (consumption <= 300) {
                    totalCharges = 200 * 0.218 + (consumption - 200) * 0.334;
                } else if (consumption <= 600) {
                    totalCharges = 200 * 0.218 + 100 * 0.334 + (consumption - 300) * 0.516;
                } else {
                    totalCharges = 200 * 0.218 + 100 * 0.334 + 300 * 0.516 + (consumption - 600) * 0.546;
                }

                double rebateAmount = totalCharges * (rebatePercentage / 100);
                double finalCost = totalCharges - rebateAmount;

                resultView.setText(String.format("Total Charges:        RM %.2f", finalCost));

            } catch (NumberFormatException nfe) {
                Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
            } catch (Exception exception) {
                Toast.makeText(this, "An error occurred", Toast.LENGTH_SHORT).show();
            }
        } else if (v == buttonClear) {
            // Clear the input fields and reset the result view
            editTextKwH.setText("");
            editTextRebate.setText("");
            resultView.setText("");
        }
    }
}
